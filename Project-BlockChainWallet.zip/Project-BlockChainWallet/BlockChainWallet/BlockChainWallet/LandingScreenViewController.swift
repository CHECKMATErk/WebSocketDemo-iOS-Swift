//
//  ViewController.swift
//  BlockChainWallet
//
//  Created by Rishik Kabra on 03/09/21.
//

import UIKit
import Combine

protocol WebSocketConnectionDelegate {
    func onConnected(connection: WebSocketConnection)
    func onDisconnected(connection: WebSocketConnection, error: Error?)
    func onError(connection: WebSocketConnection, error: Error)
    func onMessage(connection: WebSocketConnection, text: String)
    func onMessage(connection: WebSocketConnection, data: Data)
}

class LandingScreenViewController: UIViewController {
    
    @IBOutlet weak var transactionHistoryTableView: UITableView!
    @IBOutlet weak var clearButton: UIButton!
    @IBOutlet weak var loadingView: UIView!
    @IBOutlet weak var loadingActivityIndicator: UIActivityIndicatorView!
    
    @IBOutlet weak var disconnectButton: UIButton!
    
    @IBOutlet weak var connectButton: UIButton!
    
    //creating a toast label, it is also possible to use a UIAlertController for toasts
    let toastLabel = UILabel()
    
    var viewModel: [TransactionCellViewModel] = [TransactionCellViewModel]()
    //LandingScreenViewModel would contain a datasource array that would continue to change
    
    var socketConnectionObject: NetworkHelper?
    var isConnected: Bool = false
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.setupTableView()
        
        //Setup toast label
        
        // can abstract this into a generic function as well but since this is a single cell now leaving it as it is
        self.transactionHistoryTableView.register(UINib(nibName: "TransactionTableViewCell", bundle: nil), forCellReuseIdentifier: "TransactionTableViewCell")
        
        self.loadingView.layer.cornerRadius = 12
        self.disconnectButton.layer.cornerRadius = 6
        self.connectButton.layer.cornerRadius = 6
        self.clearButton.layer.cornerRadius = 12
        
        //hiding views that do not have data from the start from the user
        self.transactionHistoryTableView.isHidden = true
        self.connectButton.isHidden = true
        self.disconnectButton.isHidden = true
        self.clearButton.isHidden = true
        
        // showing loader to the user
        self.loadingActivityIndicator.startAnimating()
        
        DispatchQueue.main.async{
            self.initializeWebsocket()
            // in general I can abstract this to a function to enable/ disable button  which would take the button as parameter
            self.connectButton.isUserInteractionEnabled = false
            self.connectButton.alpha = 0.5
            //self.setupToastLabel(toastMessage: "Establishing Connection...")
            self.showToastWithMessage(toastMessage: "Establishing Connection...")
        }
    }
    
    func setUpViewModel(_ data: TransactionCellViewModel){
        if self.viewModel.count>=5 {
            self.viewModel.remove(at: 0)
        }
        self.viewModel.append(data)
        DispatchQueue.main.async {
            // we can use asyncAfter method to keep transactions for readability and maintain a separate array of all transactions and take 5 of them out at a time in a fixed interval say every 10 seconds.
            // the current solution works for realtime updates
            if self.viewModel.count >= 5{
                self.transactionHistoryTableView.reloadData()
                self.loadingView.isHidden = true
                self.loadingActivityIndicator.stopAnimating()
                self.transactionHistoryTableView.isHidden = false
                self.clearButton.isHidden = false
                self.connectButton.isHidden = false
                self.disconnectButton.isHidden = false
                
            }
        }
        
    }
    
    func setupTableView() {
        //scrolling is not disabled as the content should fit on the smallest devices as well
        self.transactionHistoryTableView.layer.cornerRadius = 12
        self.transactionHistoryTableView.separatorStyle = .none
        self.transactionHistoryTableView.estimatedRowHeight = UITableView.automaticDimension
        self.transactionHistoryTableView.tableFooterView = UIView(frame: .zero)
        self.transactionHistoryTableView.delegate = self
        self.transactionHistoryTableView.dataSource = self
    }
    
    @IBAction func connectClicked(_ sender: Any) {
        //toggling button states
        self.disconnectButton.isUserInteractionEnabled = true
        self.disconnectButton.alpha = 1
        self.connectButton.isUserInteractionEnabled = false
        self.connectButton.alpha = 0.5
        // opening connection again
        self.initializeWebsocket()
        self.showToastWithMessage(toastMessage: "Establishing Connection...")
    }
    
    @IBAction func disconnectClicked(_ sender: Any) {
        //toggling button states
        self.disconnectButton.isUserInteractionEnabled = false
        self.disconnectButton.alpha = 0.5
        self.connectButton.isUserInteractionEnabled = true
        self.connectButton.alpha = 1
        
        // closing connection
        if let socketObject = self.socketConnectionObject{
            self.disconnectConnection(socketConnection: socketObject)
        }
    }
    
    @IBAction func clearClicked(_ sender: Any) {
        // clearing list
        self.viewModel.removeAll()
        // show loader
        self.transactionHistoryTableView.isHidden = true
        self.clearButton.isHidden = true
        self.connectButton.isHidden = true
        self.disconnectButton.isHidden = true
        self.loadingView.isHidden = false
        self.loadingActivityIndicator.startAnimating()
        // remove all cells
        self.transactionHistoryTableView.reloadData()
        
            if !isConnected {
                self.initializeWebsocket()
                //changing button states
                self.connectButton.isUserInteractionEnabled = false
                self.connectButton.alpha = 0.5
                self.disconnectButton.isUserInteractionEnabled = true
                self.disconnectButton.alpha = 1
            }
    }
    
    func setupToastModel(toastMessage: String){
        // since I cannot make UI changes from background thread, using dispatch queue here
        DispatchQueue.main.async {
            self.showToastWithMessage(toastMessage: toastMessage)
        }
    }
    
    func showToastWithMessage(toastMessage: String) {
        // we can also initialise the toast label here but since it is common to this view it is initialised globally,
        // however if we want to abstract this function as a toast label creater then we should include label object creation here....
        self.view.addSubview(self.toastLabel)
        toastLabel.translatesAutoresizingMaskIntoConstraints = false
        toastLabel.backgroundColor = UIColor.black.withAlphaComponent(0.9)
        toastLabel.textColor = UIColor.white.withAlphaComponent(0.8)
        toastLabel.textAlignment = .center
        toastLabel.text = toastMessage
        if #available(iOS 11.0, *) {
            toastLabel.bottomAnchor.constraint(equalTo: self.view.safeAreaLayoutGuide.bottomAnchor, constant: -20).isActive = true
        } else {
            toastLabel.bottomAnchor.constraint(equalTo: self.view.bottomAnchor, constant: -50).isActive = true
        }
        toastLabel.centerXAnchor.constraint(equalTo: self.view.centerXAnchor).isActive = true
        toastLabel.sizeToFit()
        toastLabel.widthAnchor.constraint(equalToConstant: toastLabel.intrinsicContentSize.width + 65.0).isActive = true
        toastLabel.heightAnchor.constraint(equalToConstant: 30.0).isActive = true
        toastLabel.layer.cornerRadius = 12.0
        toastLabel.layer.masksToBounds = true
        toastLabel.alpha = 0.0
        toastLabel.contentMode = .redraw
        UIView.animate(withDuration: 0.5, animations: {
            self.toastLabel.alpha = 1.0
        }) { (isComplete) in
            UIView.animateKeyframes(withDuration: 0.5, delay: 0.5, options: [], animations: {
                self.toastLabel.alpha = 0.0
            })
        }
    }
}

extension LandingScreenViewController: UITableViewDataSource{
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // return viewmodel rows.count if we limit appending at network level or return 5
        return 5
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        if indexPath.row < 5 {
            let cell = tableView.dequeueReusableCell(withIdentifier: "TransactionTableViewCell", for: indexPath) as! TransactionTableViewCell
            // logic can be improved to included a dataSource array for the tableview into which data is being passed by the transaction list, that way we can control retrieval rates and display change rates separately
            if viewModel.count>0{
                cell.configureCell(model: viewModel[indexPath.row])
            }
            return cell
        }
        return UITableViewCell()
    }
}

extension LandingScreenViewController: UITableViewDelegate{
    
    func tableView(_ tableView: UITableView, estimatedHeightForRowAt indexPath: IndexPath) -> CGFloat {
        // test value
        return 240
    }
}

extension LandingScreenViewController{
    func initializeWebsocket(){
        if let url = URL(string: "wss://ws.blockchain.info/inv"){
            let socketConnection = NetworkHelper(withSocketURL: url)
            //saving the socket instance to disconnect if required
            self.socketConnectionObject = socketConnection
            isConnected = true
            
            self.setupConnection(socketConnection: socketConnection)
            let requestForTransactions: [String: String] = ["op":"unconfirmed_sub"]
            let encoder = JSONEncoder()
            if let jsonData = try? encoder.encode(requestForTransactions) {
                if let jsonString = String(data: jsonData, encoding: .utf8) {
                    socketConnection.send(message: jsonString)
                }
            }
        }
    }
    
    func disconnectConnection(socketConnection: NetworkHelper){
        let unsubscribe: [String: String] = ["op":"unconfirmed_unsub"]
        let encoder = JSONEncoder()
        if let jsonData = try? encoder.encode(unsubscribe) {
            if let jsonString = String(data: jsonData, encoding: .utf8) {
                socketConnection.send(message: jsonString)
            }
        }
        isConnected = false
        socketConnection.disconnect()
    }
    
    func setupConnection(socketConnection: NetworkHelper){
        socketConnection.establishConnection()
        socketConnection.didReceiveMessage = { message in
            print(message)
            do {
                let data = Data(message.utf8)
                let dataModel = try JSONDecoder().decode(TransactionCellWidgetModel.self, from: data)
                let viewModel = TransactionCellViewModel.init(dataModel)
                if let amount = viewModel.transactionAmount {
                    // 100 dollar check
                    if amount > 100 {
                        self.setUpViewModel(viewModel)
                    }
                }
            } catch {
                print(error.localizedDescription)
            }
            
        }
        
        socketConnection.didReceiveError = { error in
            //Handle error here
        }
        
        socketConnection.didOpenConnection = {
            //Connection opened
            self.setupToastModel(toastMessage: "Connection Established!")
        }
        
        socketConnection.didCloseConnection = {
            self.setupToastModel(toastMessage: "Connection Closed!")
        }
        
        socketConnection.didReceiveData = { data in
            // receive Data
        }
    }
}
