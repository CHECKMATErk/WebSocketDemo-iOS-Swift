//
//  DataHelper.swift
//  BlockChainWallet
//
//  Created by Rishik Kabra on 04/09/21.
//



// file only created to be used as an abstraction layer for data parsing when we are using multiple screens 

import UIKit
import Foundation
import Combine

protocol WebSocketConnection {
    func send(text: String)
    func send(data: Data)
    func connect()
    func disconnect()
    var delegate: WebSocketConnectionDelegate? {
        get
        set
    }
}

class DataHelper {
    
    var url: URL?
    var sourceViewController: UIViewController?
    
    init(_ urlString: String?, sourceViewController: UIViewController?){
        if let url = URL(string: "wss://ws.blockchain.info/inv"){
            self.url = url
        }
        if let sourceVC = sourceViewController{
            self.sourceViewController = sourceVC
        }
    }
    
    
    
    func initializeWebsocket(src: UIViewController){
        if let url = self.url{
            let socketConnection = NetworkHelper(withSocketURL: url)
            self.setupConnection(socketConnection: socketConnection, sourceViewController: src)
            let requestForTransactions: [String: String] = ["op":"unconfirmed_sub"]
            let encoder = JSONEncoder()
            if let jsonData = try? encoder.encode(requestForTransactions) {
                if let jsonString = String(data: jsonData, encoding: .utf8) {
                    socketConnection.send(message: jsonString)
                }
            }
        }
        
    }
    
    func setupConnection(socketConnection: NetworkHelper, sourceViewController: UIViewController){
        socketConnection.establishConnection()
        
        socketConnection.didReceiveMessage = { message in
                print(message)
                do {
                    let data = Data(message.utf8)
                        let dataModel = try JSONDecoder().decode(TransactionCellWidgetModel.self, from: data)
                        let viewModel = TransactionCellViewModel.init(dataModel)
                            if let controller = sourceViewController as? LandingScreenViewController {
                                controller.setUpViewModel(viewModel)
                            }
                        
                    

                } catch {
                    print(error.localizedDescription)
                }
            
        }
        
        socketConnection.didReceiveError = { error in
            //Handle error here
        }
        
        socketConnection.didOpenConnection = {
            //Connection opened
        }
        
        socketConnection.didCloseConnection = {
            // Connection closed
        }
        
        socketConnection.didReceiveData = { data in
            // receive Data
        }
    }
}
