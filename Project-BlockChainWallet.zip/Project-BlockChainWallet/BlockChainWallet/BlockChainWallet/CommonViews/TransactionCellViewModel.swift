//
//  TransactionCellViewModel.swift
//  BlockChainWallet
//
//  Created by Rishik Kabra on 03/09/21.
//

import Foundation

class TransactionCellViewModel{
    
    var transactionId: String?
    var transactionAmount: Double?
    var timeStamp: Date?
    
    init(_ data: TransactionCellWidgetModel?) {
        self.transactionId = data?.x?.hash
        self.transactionAmount = data?.x?.out?.first?.value
        if let doubleTime = data?.x?.time {
            let time = TimeInterval.init(doubleTime)
            self.timeStamp = Date.init(timeIntervalSince1970: time)
        }
    }
}
