//
//  TransactionCellWidgetModel.swift
//  BlockChainWallet
//
//  Created by Rishik Kabra on 03/09/21.
//

import Foundation

struct TransactionCellWidgetModel: Codable {
    let x: dataForCell?
}

struct dataForCell: Codable {
    let time: Double?
    let hash: String?
    let out: [outputModel]?
}

struct outputModel: Codable{
    let value: Double?
}
