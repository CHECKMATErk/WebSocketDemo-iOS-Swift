//
//  TransactionTableViewCell.swift
//  BlockChainWallet
//
//  Created by Rishik Kabra on 03/09/21.
//

import UIKit

class TransactionTableViewCell: UITableViewCell {
    
    @IBOutlet weak var paddingSuperView: UIView!
    @IBOutlet weak var amountLabel: UILabel!
    @IBOutlet weak var timeStampLabel: UILabel!
    @IBOutlet weak var transactionIdLabel: UILabel!
    
    
    @IBOutlet weak var leadingPaddingConstraint: NSLayoutConstraint!
    @IBOutlet weak var bottomPaddingConstraint: NSLayoutConstraint!
    @IBOutlet weak var topPaddingConstraint: NSLayoutConstraint!
    @IBOutlet weak var trailiingPaddingConstraint: NSLayoutConstraint!
    
    var viewModel: TransactionCellViewModel?
    var cellIdentifier: String?
    
    override func awakeFromNib() {
        super.awakeFromNib()
        self.paddingSuperView.layer.cornerRadius = 8
        // Initialization code
    }
    
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
    }
    
    func configureCell(model: TransactionCellViewModel){
        self.viewModel = model
        self.updateUI()
    }
    
    func updateUI(){
        if let date = viewModel?.timeStamp {
            let dateText = DateFormatter.localizedString(from: date, dateStyle: .long, timeStyle: .long)
            self.timeStampLabel.text = dateText
        }
        if let txnId = viewModel?.transactionId{
            self.transactionIdLabel.text = txnId
        }
        if let amount = viewModel?.transactionAmount{
            self.amountLabel.text = "$ " + String(amount)
        }
       
    }
    
    
}
