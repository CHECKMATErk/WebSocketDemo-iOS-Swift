//
//  LandingScreenViewModel.swift
//  BlockChainWallet
//
//  Created by Rishik Kabra on 03/09/21.
//

import Foundation

class LandingScreenViewModel {
        // file created as stub to be used if the screen data was to be fetched from a static rest api
}
